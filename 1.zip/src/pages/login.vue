<script setup lang="ts">
const email = ref('');
const password = ref('');
const errorMsg = ref('');
const loading = ref(false);
const router = useRouter();
const auth = useAuthStore();

async function handleLogin() {
  if (!email.value || !password.value) {
    return;
  }

  loading.value = true;
  errorMsg.value = '';
  const result = await auth.login(email.value, password.value);

  if (result.error) {
    errorMsg.value = 'Invalid email or password';
  } else {
    router.push('/dashboard');
  }

  loading.value = false;
}
</script>

<template>
  <div class="flex min-h-screen items-center justify-center bg-american-diamond p-4">
    <div class="w-full max-w-sm">
      <div class="mb-8 text-center">
        <h1 class="text-xl font-bold text-casual-navy">WRS Management</h1>
        <p class="mt-1 text-sm text-independence">Water Refilling Station</p>
      </div>
      <BaseCard>
        <form class="space-y-4" @submit.prevent="handleLogin">
          <BaseInput v-model="email" label="Email" type="email" placeholder="admin@example.com" :required="true" />
          <BaseInput v-model="password" label="Password" type="password" placeholder="••••••••" :required="true" />
          <p v-if="errorMsg" class="text-sm text-blaze-red">{{ errorMsg }}</p>
          <BaseButton type="submit" class="w-full" :loading="loading"> Sign in </BaseButton>
        </form>
      </BaseCard>
    </div>
  </div>
</template>
