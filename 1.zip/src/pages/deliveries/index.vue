<script setup lang="ts">
import type { User, Product, ContainerType, CustomerAddress } from '@/types/database';

const auth = useAuthStore();
const tenantId = computed(() => auth.tenantId ?? '');
const branchId = computed(() => auth.branchId ?? '');

// ─── Date picker ────────────────────────────────────────────────────────────
const selectedDate = ref(new Date().toISOString().slice(0, 10));

// ─── Board data ─────────────────────────────────────────────────────────────
const deliveries = ref<DeliverySaleRow[]>([]);
const boardLoading = ref(false);

async function loadDeliveries() {
  boardLoading.value = true;
  try {
    deliveries.value = await listDeliverySales(selectedDate.value);
  } finally {
    boardLoading.value = false;
  }
}

watch(selectedDate, loadDeliveries);
onMounted(loadDeliveries);

// Group deliveries by rider_id
const groups = computed(() => {
  const map = new Map<string | null, { riderName: string; items: DeliverySaleRow[] }>();

  for (const d of deliveries.value) {
    const key = d.rider_id;

    if (!map.has(key)) {
      map.set(key, {
        riderName: d.rider?.full_name ?? 'Unassigned',
        items: [],
      });
    }

    map.get(key)!.items.push(d);
  }

  // Put unassigned last
  const entries = [...map.entries()].sort(([a], [b]) => {
    if (a === null) {
      return 1;
    }

    if (b === null) {
      return -1;
    }

    return 0;
  });

  return entries.map(([key, val]) => ({ riderId: key, ...val }));
});

// ─── Helpers ─────────────────────────────────────────────────────────────────
function saleTotal(sale: DeliverySaleRow): number {
  return sale.lines.reduce((sum, l) => sum + l.quantity * l.unit_price_centavos, 0);
}

// ─── Reconcile modal ─────────────────────────────────────────────────────────
const reconcileOpen = ref(false);
const reconcilingSale = ref<DeliverySaleRow | null>(null);
const reconcileReturns = ref<Array<{ container_type_id: string; name: string; maxQty: number; qty: number }>>([]);
const reconcileNotes = ref('');
const reconcileSaving = ref(false);

function openReconcile(sale: DeliverySaleRow) {
  reconcilingSale.value = sale;
  reconcileNotes.value = '';

  // Build unique container types from lines
  const seen = new Map<string, { name: string; totalQty: number }>();

  for (const line of sale.lines) {
    const existing = seen.get(line.container_type_id);

    if (existing) {
      existing.totalQty += line.quantity;
    } else {
      seen.set(line.container_type_id, {
        name: line.container_type?.name ?? line.container_type_id,
        totalQty: line.quantity,
      });
    }
  }

  reconcileReturns.value = [...seen.entries()].map(([id, v]) => ({
    container_type_id: id,
    name: v.name,
    maxQty: v.totalQty,
    qty: 0,
  }));

  reconcileOpen.value = true;
}

async function submitReconcile() {
  if (!reconcilingSale.value) {
    return;
  }

  reconcileSaving.value = true;
  try {
    await reconcileDelivery({
      saleId: reconcilingSale.value.id,
      customerId: reconcilingSale.value.customer_id,
      tenantId: tenantId.value,
      branchId: branchId.value,
      containersReturned: reconcileReturns.value.map((r) => ({
        container_type_id: r.container_type_id,
        quantity: r.qty,
      })),
      notes: reconcileNotes.value || null,
    });
    reconcileOpen.value = false;
    reconcilingSale.value = null;
    await loadDeliveries();
  } finally {
    reconcileSaving.value = false;
  }
}

// ─── New Delivery modal ───────────────────────────────────────────────────────
const newDeliveryOpen = ref(false);

// Support data
const customers = ref<Array<{ id: string; name: string; phone: string | null }>>([]);
const riders = ref<Array<Pick<User, 'id' | 'full_name'>>>([]);
const products = ref<Product[]>([]);
const containerTypes = ref<ContainerType[]>([]);

// Form state
const ndForm = reactive({
  customer_id: '',
  rider_id: '',
  address_id: '',
  sale_date: new Date().toISOString().slice(0, 10),
  notes: '',
  payment_method: 'cash',
  payment_amount: '',
  payment_gcash_ref: '',
});

const ndLines = ref<
  Array<{
    product_id: string;
    container_type_id: string;
    quantity: number;
    unit_price_centavos: number;
    is_new_container: boolean;
  }>
>([]);

const customerAddresses = ref<CustomerAddress[]>([]);
const ndSaving = ref(false);
const ndCustomerSearch = ref('');

// Filtered customers for search
const filteredCustomers = computed(() => {
  const q = ndCustomerSearch.value.toLowerCase();

  if (!q) {
    return customers.value;
  }

  return customers.value.filter((c) => c.name.toLowerCase().includes(q));
});

const customerOptions = computed(() => filteredCustomers.value.map((c) => ({ label: c.name, value: c.id })));

const riderOptions = computed(() => [{ label: '— No rider —', value: '' }, ...riders.value.map((r) => ({ label: r.full_name, value: r.id }))]);

const addressOptions = computed(() =>
  customerAddresses.value.map((a) => ({
    label: `${a.label} — ${a.address_line}`,
    value: a.id,
  })),
);

const productOptions = computed(() => products.value.map((p) => ({ label: p.name, value: p.id })));

const containerTypeOptions = computed(() => containerTypes.value.map((c) => ({ label: c.name, value: c.id })));

async function loadSupportData() {
  const [custRes, riderRes, prodRes, ctRes] = await Promise.all([
    listCustomers(tenantId.value, branchId.value),
    listRiders(tenantId.value, branchId.value),
    listProducts(tenantId.value, branchId.value),
    listContainerTypes(tenantId.value, branchId.value),
  ]);

  customers.value = (custRes.data ?? []) as Array<{ id: string; name: string; phone: string | null }>;
  riders.value = (riderRes.data ?? []) as Array<Pick<User, 'id' | 'full_name'>>;
  products.value = (prodRes.data ?? []) as Product[];
  containerTypes.value = (ctRes.data ?? []) as ContainerType[];
}

watch(
  () => ndForm.customer_id,
  async (id) => {
    customerAddresses.value = [];
    ndForm.address_id = '';
    if (!id) {
      return;
    }

    const { data } = await listAddresses(id);

    customerAddresses.value = (data ?? []) as CustomerAddress[];
    const def = customerAddresses.value.find((a) => a.is_default);

    if (def) {
      ndForm.address_id = def.id;
    }
  },
);

function openNewDelivery() {
  ndForm.customer_id = '';
  ndForm.rider_id = '';
  ndForm.address_id = '';
  ndForm.sale_date = selectedDate.value;
  ndForm.notes = '';
  ndForm.payment_method = 'cash';
  ndForm.payment_amount = '';
  ndForm.payment_gcash_ref = '';
  ndCustomerSearch.value = '';
  ndLines.value = [newLine()];
  customerAddresses.value = [];
  newDeliveryOpen.value = true;
  loadSupportData();
}

function newLine() {
  return {
    product_id: '',
    container_type_id: '',
    quantity: 1,
    unit_price_centavos: 0,
    is_new_container: false,
  };
}

function addLine() {
  ndLines.value.push(newLine());
}

function removeLine(idx: number) {
  ndLines.value.splice(idx, 1);
}

const ndTotal = computed(() => ndLines.value.reduce((s, l) => s + l.quantity * l.unit_price_centavos, 0));

async function submitNewDelivery() {
  ndSaving.value = true;
  try {
    const amountCentavos = Math.round(parseFloat(ndForm.payment_amount || '0') * 100);

    await createDeliverySale({
      tenant_id: tenantId.value,
      branch_id: branchId.value,
      customer_id: ndForm.customer_id,
      address_id: ndForm.address_id || null,
      rider_id: ndForm.rider_id || null,
      sale_date: ndForm.sale_date,
      notes: ndForm.notes || null,
      lines: ndLines.value.filter((l) => l.product_id && l.container_type_id),
      payments:
        amountCentavos > 0
          ? [
              {
                method: ndForm.payment_method,
                amount_centavos: amountCentavos,
                gcash_ref: ndForm.payment_method === 'gcash' ? ndForm.payment_gcash_ref || null : null,
              },
            ]
          : [],
    });
    newDeliveryOpen.value = false;
    if (ndForm.sale_date === selectedDate.value) {
      await loadDeliveries();
    }
  } finally {
    ndSaving.value = false;
  }
}

// ─── Status helpers ───────────────────────────────────────────────────────────
function statusLabel(status: string) {
  if (status === 'pending_delivery') {
    return 'Pending';
  }

  if (status === 'completed') {
    return 'Delivered';
  }

  return status;
}

function statusVariant(status: string): 'warning' | 'success' | 'default' {
  if (status === 'pending_delivery') {
    return 'warning';
  }

  if (status === 'completed') {
    return 'success';
  }

  return 'default';
}
</script>

<template>
  <div class="h-full overflow-y-auto p-6">
    <div class="space-y-5">
      <!-- Header -->
      <div class="flex flex-wrap items-center gap-3">
        <div>
          <h1 class="text-2xl font-bold text-casual-navy">Deliveries</h1>
          <p class="text-sm text-oslo">Track and manage all delivery orders</p>
        </div>
        <div class="ml-auto flex items-center gap-2">
          <BaseInput v-model="selectedDate" type="date" class="w-44" />
          <BaseButton size="sm" @click="openNewDelivery">New Delivery</BaseButton>
        </div>
      </div>

      <!-- Board -->
      <BaseSpinner v-if="boardLoading" class="mx-auto mt-10" />

      <BaseEmptyState v-else-if="deliveries.length === 0" title="No deliveries" description="No delivery sales for this date." />

      <div v-else class="space-y-8">
        <section v-for="group in groups" :key="group.riderId ?? 'unassigned'">
          <!-- Group header -->
          <div class="mb-3 flex items-center gap-2">
            <h2 class="text-sm font-semibold text-casual-navy">{{ group.riderName }}</h2>
            <span
              class="inline-flex items-center justify-center rounded-full bg-[--color-surface-raised] px-2 py-0.5 text-xs font-medium text-independence"
            >
              {{ group.items.length }}
            </span>
          </div>

          <!-- Cards grid -->
          <div class="grid gap-3 grid-cols-3">
            <BaseCard v-for="sale in group.items" :key="sale.id" padding="sm" class="flex flex-col gap-2">
              <!-- Customer + status -->
              <div class="flex items-start justify-between gap-2">
                <div>
                  <p class="font-medium text-casual-navy">
                    {{ sale.customer?.name ?? '—' }}
                  </p>
                  <p v-if="sale.customer?.phone" class="text-xs text-independence">
                    {{ sale.customer.phone }}
                  </p>
                </div>
                <BaseBadge :variant="statusVariant(sale.status)" size="sm">
                  {{ statusLabel(sale.status) }}
                </BaseBadge>
              </div>

              <!-- Address -->
              <p v-if="sale.address" class="text-xs text-independence">{{ sale.address.label }} — {{ sale.address.address_line }}</p>

              <!-- Lines -->
              <ul class="space-y-0.5">
                <li v-for="line in sale.lines" :key="line.id" class="text-xs text-casual-navy">
                  {{ line.quantity }}× {{ line.container_type?.name ?? '?' }}
                  {{ line.product?.name ?? '' }}
                  <span class="text-independence">
                    @ <span class="num">{{ formatMoney(line.unit_price_centavos) }}</span>
                  </span>
                </li>
              </ul>

              <!-- Total -->
              <p class="text-sm font-semibold text-casual-navy">
                Total: <span class="num">{{ formatMoney(saleTotal(sale)) }}</span>
              </p>

              <!-- Notes -->
              <p v-if="sale.notes" class="text-xs italic text-independence">{{ sale.notes }}</p>

              <!-- Action -->
              <div v-if="sale.status === 'pending_delivery'" class="pt-1">
                <BaseButton size="sm" variant="secondary" @click="openReconcile(sale)"> Reconcile </BaseButton>
              </div>
              <p v-else class="pt-1 text-xs text-independence">Delivered</p>
            </BaseCard>
          </div>
        </section>
      </div>
    </div>

    <!-- ── Reconcile modal ──────────────────────────────────────────────────── -->
    <BaseModal :open="reconcileOpen" title="Reconcile Delivery" size="md" @close="reconcileOpen = false">
      <div v-if="reconcilingSale" class="space-y-4">
        <!-- Summary -->
        <div class="rounded-lg bg-[--color-surface-raised] p-3 text-sm">
          <p class="font-medium text-casual-navy">
            {{ reconcilingSale.customer?.name ?? '—' }}
          </p>
          <ul class="mt-1 space-y-0.5 text-independence">
            <li v-for="line in reconcilingSale.lines" :key="line.id">
              {{ line.quantity }}× {{ line.container_type?.name ?? '?' }} {{ line.product?.name ?? '' }}
            </li>
          </ul>
        </div>

        <!-- Container returns -->
        <div class="space-y-3">
          <p class="text-sm font-medium text-casual-navy">Containers Returned</p>
          <div v-for="ret in reconcileReturns" :key="ret.container_type_id" class="flex items-center gap-3">
            <span class="flex-1 text-sm text-casual-navy">{{ ret.name }}</span>
            <div class="w-24">
              <input
                v-model.number="ret.qty"
                type="number"
                :min="0"
                :max="ret.maxQty"
                class="w-full rounded-md border border-sparkling-silver bg-full-white px-3 py-1.5 text-sm text-casual-navy focus:outline-none focus:ring-2 focus:ring-turquoise-stone"
              />
            </div>
            <span class="w-16 text-right text-xs text-independence"> of {{ ret.maxQty }} </span>
          </div>
        </div>

        <!-- Notes -->
        <BaseTextarea v-model="reconcileNotes" label="Notes (optional)" :rows="2" />
      </div>

      <template #footer>
        <BaseButton variant="ghost" @click="reconcileOpen = false">Cancel</BaseButton>
        <BaseButton :loading="reconcileSaving" @click="submitReconcile"> Mark Delivered </BaseButton>
      </template>
    </BaseModal>

    <!-- ── New Delivery modal ───────────────────────────────────────────────── -->
    <BaseModal :open="newDeliveryOpen" title="New Delivery" size="xl" @close="newDeliveryOpen = false">
      <form id="new-delivery-form" class="space-y-5" @submit.prevent="submitNewDelivery">
        <!-- Customer search + select -->
        <div class="space-y-1">
          <label class="text-xs font-medium text-oslo">Customer <span class="text-blaze-red">*</span></label>
          <input
            v-model="ndCustomerSearch"
            type="search"
            placeholder="Search customer..."
            class="mb-1 w-full rounded-md border border-sparkling-silver bg-full-white px-3 py-2 text-sm text-casual-navy placeholder:text-oslo focus:outline-none focus:ring-2 focus:ring-turquoise-stone"
          />
          <BaseSelect v-model="ndForm.customer_id" :options="customerOptions" placeholder="Select customer..." :required="true" />
        </div>

        <div class="grid gap-4 grid-cols-2">
          <!-- Rider -->
          <BaseSelect v-model="ndForm.rider_id" label="Rider" :options="riderOptions" placeholder="Select rider..." />

          <!-- Address -->
          <BaseSelect
            v-model="ndForm.address_id"
            label="Delivery Address"
            :options="addressOptions"
            placeholder="Select address..."
            :disabled="!ndForm.customer_id"
          />
        </div>

        <!-- Date -->
        <BaseInput v-model="ndForm.sale_date" label="Delivery Date" type="date" :required="true" />

        <!-- Line items -->
        <div class="space-y-2">
          <p class="text-sm font-medium text-casual-navy">Items</p>

          <div v-for="(line, idx) in ndLines" :key="idx" class="grid grid-cols-[1fr_1fr_4rem_6rem_auto] items-end gap-2">
            <BaseSelect v-model="line.product_id" :options="productOptions" placeholder="Product..." />
            <BaseSelect v-model="line.container_type_id" :options="containerTypeOptions" placeholder="Container..." />
            <BaseInput v-model="line.quantity" type="number" placeholder="Qty" />
            <BaseInput
              :model-value="(line.unit_price_centavos / 100).toFixed(2)"
              type="number"
              placeholder="Price (₱)"
              @update:model-value="(v) => (line.unit_price_centavos = Math.round(Number(v) * 100))"
            />
            <button
              type="button"
              class="pb-1 text-independence hover:text-blaze-red focus:outline-none"
              aria-label="Remove line"
              @click="removeLine(idx)"
            >
              <svg xmlns="http://www.w3.org/2000/svg" class="size-4" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                <path
                  fill-rule="evenodd"
                  d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
                  clip-rule="evenodd"
                />
              </svg>
            </button>
          </div>

          <BaseButton type="button" variant="ghost" size="sm" @click="addLine">+ Add item</BaseButton>

          <p class="text-right text-sm font-semibold text-casual-navy">
            Total: <span class="num">{{ formatMoney(ndTotal) }}</span>
          </p>
        </div>

        <!-- Payment -->
        <div class="space-y-3">
          <p class="text-sm font-medium text-casual-navy">Payment</p>
          <div class="grid gap-3 grid-cols-2">
            <BaseSelect
              v-model="ndForm.payment_method"
              label="Method"
              :options="[
                { label: 'Cash', value: 'cash' },
                { label: 'GCash', value: 'gcash' },
                { label: 'On Account', value: 'on_account' },
              ]"
            />
            <BaseInput v-model="ndForm.payment_amount" label="Amount (₱)" type="number" placeholder="0.00" />
          </div>
          <BaseInput v-if="ndForm.payment_method === 'gcash'" v-model="ndForm.payment_gcash_ref" label="GCash Reference #" placeholder="e.g. 1234567890" />
        </div>

        <!-- Notes -->
        <BaseTextarea v-model="ndForm.notes" label="Notes" :rows="2" />
      </form>

      <template #footer>
        <BaseButton variant="ghost" @click="newDeliveryOpen = false">Cancel</BaseButton>
        <BaseButton type="submit" form="new-delivery-form" :loading="ndSaving"> Create Delivery </BaseButton>
      </template>
    </BaseModal>
  </div>
</template>
