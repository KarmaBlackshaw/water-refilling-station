<script setup lang="ts">
import { supabase } from '@/helpers/supabase';
import { formatMoney } from '@/helpers/money';
import type { DeliverySaleRow } from '@/services/deliveries';
import type { BookingRow } from '@/services/bookings';
import type { MaintenanceTask } from '@/types/database';

const todayDate = new Date().toLocaleDateString('en-CA', { timeZone: 'Asia/Manila' });
const todayPlus3Date = (() => {
  const d = new Date(todayDate);

  d.setDate(d.getDate() + 3);
  return d.toISOString().slice(0, 10);
})();
const todayDisplay = new Date().toLocaleDateString('en-PH', {
  timeZone: 'Asia/Manila',
  weekday: 'long',
  year: 'numeric',
  month: 'long',
  day: 'numeric',
});

function getPast7Days(): string[] {
  return Array.from({ length: 7 }, (_, i) => {
    const d = new Date(todayDate);

    d.setDate(d.getDate() - (6 - i));
    return d.toISOString().slice(0, 10);
  });
}

// ── State ─────────────────────────────────────────────────────────────────────
const loading = ref(true);
const todayRevenue = ref(0);
const deliveries = ref<DeliverySaleRow[]>([]);
const bookings = ref<BookingRow[]>([]);
const maintenanceAlertCount = ref(0);
const weeklyRevenueLabels = ref<string[]>([]);
const weeklyRevenueData = ref<number[]>([]);
const weeklyDeliverySegments = ref<{ label: string; value: number; color: string }[]>([]);

// ── Computed ──────────────────────────────────────────────────────────────────
const pendingDeliveries = computed(() => deliveries.value.filter((d) => d.status === 'pending_delivery'));
const upcomingBookingCount = computed(() => bookings.value.length);
const deliveryCompletionLabel = computed(() => {
  const total = weeklyDeliverySegments.value.reduce((s, seg) => s + seg.value, 0);

  if (total === 0) {
    return '0%';
  }

  const done = weeklyDeliverySegments.value.find((s) => s.label === 'Completed')?.value ?? 0;

  return `${Math.round((done / total) * 100)}%`;
});

// ── Data loading ──────────────────────────────────────────────────────────────
async function loadRevenue(): Promise<void> {
  const { data: sales } = await supabase.from('sales').select('id').eq('sale_date', todayDate).eq('status', 'completed').is('deleted_at', null);
  const saleIds = (sales ?? []).map((s: { id: string }) => s.id);

  if (saleIds.length === 0) {
    todayRevenue.value = 0;
    return;
  }

  const { data: payments } = await supabase.from('sale_payments').select('amount_centavos').in('sale_id', saleIds);

  todayRevenue.value = (payments ?? []).reduce((sum: number, p: { amount_centavos: number }) => sum + p.amount_centavos, 0);
}

async function loadWeeklyRevenue(): Promise<void> {
  const days = getPast7Days();
  const { data: sales } = await supabase
    .from('sales')
    .select('id, sale_date')
    .gte('sale_date', days[0])
    .lte('sale_date', days[6])
    .eq('status', 'completed')
    .is('deleted_at', null);

  const saleDateMap: Record<string, string> = Object.fromEntries((sales ?? []).map((s: { id: string; sale_date: string }) => [s.id, s.sale_date]));
  const saleIds = Object.keys(saleDateMap);
  const dayTotals: Record<string, number> = Object.fromEntries(days.map((d) => [d, 0]));

  if (saleIds.length > 0) {
    const { data: payments } = await supabase.from('sale_payments').select('sale_id, amount_centavos').in('sale_id', saleIds);

    for (const p of payments ?? []) {
      const date = saleDateMap[p.sale_id as string];

      if (date) {
        dayTotals[date] = (dayTotals[date] ?? 0) + (p.amount_centavos as number);
      }
    }
  }

  weeklyRevenueLabels.value = days.map((d) => new Date(d + 'T00:00:00').toLocaleDateString('en-PH', { weekday: 'short' }));
  weeklyRevenueData.value = days.map((d) => Math.round((dayTotals[d] ?? 0) / 100));
}

async function loadWeeklyDeliveries(): Promise<void> {
  const days = getPast7Days();
  const results = await Promise.all(days.map((d) => listDeliverySales(d)));
  const all = results.flat();

  weeklyDeliverySegments.value = [
    { label: 'Completed', value: all.filter((d) => d.status === 'completed' || d.status === 'booking_fulfilled').length, color: '#00C9F0' },
    { label: 'Pending', value: all.filter((d) => d.status === 'pending_delivery').length, color: '#F59E0B' },
    { label: 'Void', value: all.filter((d) => d.status === 'void').length, color: '#CBD5E1' },
  ];
}

async function loadDeliveries(): Promise<void> {
  deliveries.value = await listDeliverySales(todayDate);
}

async function loadBookings(): Promise<void> {
  bookings.value = await listBookings({ from: todayDate, to: todayPlus3Date, status: 'pending' });
}

async function loadMaintenance(): Promise<void> {
  const [plantTasks, vehicleTasks] = await Promise.all([listTasks('water_plant'), listTasks('vehicle')]);
  const allTasks: MaintenanceTask[] = [...plantTasks, ...vehicleTasks];

  maintenanceAlertCount.value = allTasks.filter((t) => t.next_due_at !== null && t.next_due_at < todayDate).length;
}

const router = useRouter();

onMounted(async () => {
  try {
    await Promise.all([loadRevenue(), loadWeeklyRevenue(), loadWeeklyDeliveries(), loadDeliveries(), loadBookings(), loadMaintenance()]);
  } finally {
    loading.value = false;
  }
});
</script>

<template>
  <div v-if="loading" class="flex h-full items-center justify-center">
    <BaseSpinner size="lg" />
  </div>

  <div v-else class="flex h-full overflow-hidden">
    <!-- Main content -->
    <div class="flex-1 overflow-y-auto p-6">
      <div class="space-y-5">
        <!-- Header -->
        <div class="flex items-center justify-between">
          <div>
            <h1 class="text-2xl font-bold text-casual-navy">Dashboard</h1>
            <p class="text-sm text-oslo">{{ todayDisplay }} · Manage your operations at a glance</p>
          </div>
          <div class="flex items-center gap-2">
            <BaseButton variant="primary" size="md" @click="router.push('/sales')"> <IconPlus :size="14" /> New Sale </BaseButton>
            <BaseButton variant="secondary" size="md" @click="router.push('/deliveries')"> View Deliveries </BaseButton>
          </div>
        </div>

        <!-- KPI row -->
        <div class="grid grid-cols-4 gap-4">
          <BaseKpiCard variant="hero" label="Today's Revenue" :value="formatMoney(todayRevenue)" sub="Completed sales today">
            <template #icon><IconMoney :size="18" class="text-white" /></template>
          </BaseKpiCard>
          <BaseKpiCard
            :variant="pendingDeliveries.length > 0 ? 'warning' : 'default'"
            label="Pending Deliveries"
            :value="pendingDeliveries.length"
            sub="Awaiting delivery today"
            to="/deliveries"
          >
            <template #icon><IconDeliveries :size="18" class="text-turquoise-stone" /></template>
          </BaseKpiCard>
          <BaseKpiCard label="Upcoming Bookings" :value="upcomingBookingCount" sub="Bookings in next 3 days" to="/bookings">
            <template #icon><IconBookings :size="18" class="text-turquoise-stone" /></template>
          </BaseKpiCard>
          <BaseKpiCard
            :variant="maintenanceAlertCount > 0 ? 'danger' : 'default'"
            label="Maintenance Alerts"
            :value="maintenanceAlertCount"
            sub="Tasks overdue"
            to="/maintenance"
          >
            <template #icon><IconMaintenance :size="18" class="text-turquoise-stone" /></template>
          </BaseKpiCard>
        </div>

        <!-- Charts row -->
        <div class="grid grid-cols-2 gap-4">
          <BaseCard padding="md">
            <BaseBarChart title="Revenue — Past 7 Days" :labels="weeklyRevenueLabels" :data="weeklyRevenueData" />
          </BaseCard>
          <BaseCard padding="md">
            <BaseDonutChart title="Deliveries — Past 7 Days" :segments="weeklyDeliverySegments" :center-label="deliveryCompletionLabel" />
          </BaseCard>
        </div>

        <!-- Lists row -->
        <div class="grid grid-cols-2 gap-4">
          <DashboardDeliveryList :deliveries="deliveries" />
          <DashboardBookingList :bookings="bookings" />
        </div>
      </div>
    </div>

    <!-- Right panel (desktop only) -->
    <aside class="flex w-[200px] shrink-0 flex-col gap-4 overflow-y-auto border-l border-sparkling-silver bg-full-white p-3 ">
      <DashboardRoutePanel />
      <DashboardQuickActions />
    </aside>
  </div>
</template>
