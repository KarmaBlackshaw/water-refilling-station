<script setup lang="ts">
import type { Employee, UserRole } from '@/types/database';
import { formatMoney, parseMoney } from '@/helpers/money';

const auth = useAuthStore();
const tenantId = computed(() => auth.tenantId ?? '');
const branchId = computed(() => auth.branchId ?? '');

const employees = ref<Employee[]>([]);
const loading = ref(false);
const modalOpen = ref(false);
const editingEmployee = ref<Employee | null>(null);
const deleteConfirm = ref<Employee | null>(null);
const saving = ref(false);

const form = reactive({
  full_name: '',
  phone: '',
  hire_date: '',
  role: 'rider' as UserRole,
  monthly_salary_display: '',
  daily_quota_jugs: '',
});

const roleOptions = [
  { label: 'Rider', value: 'rider' },
  { label: 'Admin', value: 'admin' },
];

async function load() {
  loading.value = true;
  const { data } = await listEmployees(tenantId.value, branchId.value);

  employees.value = data ?? [];
  loading.value = false;
}

onMounted(load);

function openAdd() {
  editingEmployee.value = null;
  form.full_name = '';
  form.phone = '';
  form.hire_date = '';
  form.role = 'rider';
  form.monthly_salary_display = formatMoney(0);
  form.daily_quota_jugs = '';
  modalOpen.value = true;
}

function openEdit(e: Employee) {
  editingEmployee.value = e;
  form.full_name = e.full_name;
  form.phone = e.phone ?? '';
  form.hire_date = e.hire_date ?? '';
  form.role = e.role;
  form.monthly_salary_display = formatMoney(e.monthly_salary_centavos);
  form.daily_quota_jugs = e.daily_quota_jugs != null ? String(e.daily_quota_jugs) : '';
  modalOpen.value = true;
}

async function save() {
  saving.value = true;
  const salary = parseMoney(form.monthly_salary_display);
  const quota = form.daily_quota_jugs ? parseInt(form.daily_quota_jugs, 10) : null;
  const payload = {
    full_name: form.full_name,
    phone: form.phone || undefined,
    hire_date: form.hire_date || undefined,
    role: form.role,
    monthly_salary_centavos: salary,
    daily_quota_jugs: quota,
  };

  if (editingEmployee.value) {
    await updateEmployee(editingEmployee.value.id, payload);
  } else {
    await createEmployee({ tenant_id: tenantId.value, branch_id: branchId.value, ...payload });
  }

  modalOpen.value = false;
  await load();
  saving.value = false;
}

async function confirmDelete() {
  if (!deleteConfirm.value || !auth.authUser) {
    return;
  }

  await softDeleteEmployee(deleteConfirm.value.id, auth.authUser.id);
  deleteConfirm.value = null;
  await load();
}
</script>

<template>
  <div class="h-full overflow-y-auto p-6">
    <div class="space-y-4">
      <div class="flex items-center justify-between">
        <div>
          <h1 class="text-2xl font-bold text-casual-navy">Employees</h1>
          <p class="text-sm text-oslo">Manage staff accounts and roles</p>
        </div>
        <BaseButton size="sm" @click="openAdd">Add employee</BaseButton>
      </div>

      <BaseSpinner v-if="loading" class="mx-auto mt-8" />
      <BaseEmptyState v-else-if="employees.length === 0" title="No employees yet">
        <template #actions>
          <BaseButton size="sm" @click="openAdd">Add first employee</BaseButton>
        </template>
      </BaseEmptyState>
      <BaseCard v-else padding="none">
        <BaseTable>
          <template #head>
            <BaseTr>
              <BaseTh>Name</BaseTh>
              <BaseTh>Role</BaseTh>
              <BaseTh>Monthly salary</BaseTh>
              <BaseTh>Status</BaseTh>
              <BaseTh></BaseTh>
            </BaseTr>
          </template>
          <template #body>
            <BaseTr v-for="e in employees" :key="e.id">
              <BaseTd>
                <RouterLink :to="`/employees/${e.id}`" class="font-medium text-turquoise-stone hover:underline">
                  {{ e.full_name }}
                </RouterLink>
              </BaseTd>
              <BaseTd>
                <BaseBadge :variant="e.role === 'admin' ? 'info' : 'default'">{{ e.role }}</BaseBadge>
              </BaseTd>
              <BaseTd class="num">{{ formatMoney(e.monthly_salary_centavos) }}</BaseTd>
              <BaseTd>
                <BaseBadge :variant="e.active ? 'success' : 'default'">{{ e.active ? 'Active' : 'Inactive' }}</BaseBadge>
              </BaseTd>
              <BaseTd class="text-right">
                <BaseButton variant="ghost" size="sm" @click="openEdit(e)">Edit</BaseButton>
                <BaseButton variant="ghost" size="sm" class="text-blaze-red" @click="deleteConfirm = e">Delete</BaseButton>
              </BaseTd>
            </BaseTr>
          </template>
        </BaseTable>
      </BaseCard>
    </div>

    <BaseModal :open="modalOpen" :title="editingEmployee ? 'Edit employee' : 'Add employee'" @close="modalOpen = false">
      <form id="employee-form" class="space-y-4" @submit.prevent="save">
        <BaseInput v-model="form.full_name" label="Full name" :required="true" />
        <BaseInput v-model="form.phone" label="Phone" type="tel" />
        <BaseInput v-model="form.hire_date" label="Hire date" type="date" />
        <BaseSelect v-model="form.role" label="Role" :options="roleOptions" />
        <BaseInput v-model="form.monthly_salary_display" label="Monthly salary" placeholder="₱0.00" />
        <BaseInput v-model="form.daily_quota_jugs" label="Daily quota (jugs) — riders only" type="number" helper-text="Leave blank to use the tenant default" />
      </form>
      <template #footer>
        <BaseButton variant="ghost" @click="modalOpen = false">Cancel</BaseButton>
        <BaseButton type="submit" form="employee-form" :loading="saving">Save</BaseButton>
      </template>
    </BaseModal>

    <BaseConfirm
      :open="deleteConfirm !== null"
      title="Delete employee?"
      :message="`Delete '${deleteConfirm?.full_name}'?`"
      @confirm="confirmDelete"
      @cancel="deleteConfirm = null"
    />
  </div>
</template>
