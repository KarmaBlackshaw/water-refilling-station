<script setup lang="ts">
import { formatMoney, parseMoney } from '@/helpers/money';
import { computeIncome, getPeriodDates } from '@/composables/usePayroll';
import type { Employee, EmployeeAttendance, SalaryRecord } from '@/types/database';

const route = useRoute();
const auth = useAuthStore();
const tenantId = computed(() => auth.tenantId ?? '');
const branchId = computed(() => auth.branchId ?? '');

const employee = ref<Employee | null>(null);
const attendance = ref<EmployeeAttendance[]>([]);
const salaryRecords = ref<SalaryRecord[]>([]);
const loading = ref(true);

const today = new Date().toISOString().slice(0, 10);

async function load() {
  const id = route.params.id as string;

  loading.value = true;

  const [empRes, attRes, salRes] = await Promise.all([
    getEmployee(id),
    listAttendanceForMonth(id, new Date().getFullYear(), new Date().getMonth() + 1),
    listSalaryRecords(id),
  ]);

  employee.value = empRes.data;
  attendance.value = attRes.data ?? [];
  salaryRecords.value = salRes.data ?? [];
  loading.value = false;
}

onMounted(load);

const todayAttendance = computed(() => attendance.value.find((a) => a.attendance_date === today));

async function toggleTodayAttendance() {
  if (!employee.value) {
    return;
  }

  const current = todayAttendance.value?.status;
  const next = current === 'present' ? 'absent' : 'present';

  await upsertAttendance({
    tenant_id: tenantId.value,
    branch_id: branchId.value,
    employee_id: employee.value.id,
    attendance_date: today,
    status: next,
  });
  await load();
}

// Income computations (commission shown as 0 — TODO in T10)
function getIncomeBreakdown(period: 'today' | 'this_week' | 'this_month') {
  if (!employee.value) {
    return null;
  }

  const { start, end } = getPeriodDates(period);

  return computeIncome(employee.value, start, end, attendance.value, {});
}

const todayIncome = computed(() => getIncomeBreakdown('today'));
const weekIncome = computed(() => getIncomeBreakdown('this_week'));
const monthIncome = computed(() => getIncomeBreakdown('this_month'));

// Salary record creation
const salaryModalOpen = ref(false);
const salaryForm = reactive({
  period_start: '',
  period_end: '',
  base_pay_display: '',
  commission_display: '',
  gross_display: '',
  notes: '',
});
const salarySaving = ref(false);

function openCreateSalary(period: 'today' | 'this_week' | 'this_month') {
  const breakdown = getIncomeBreakdown(period);
  const { start, end } = getPeriodDates(period);

  salaryForm.period_start = start.toISOString().slice(0, 10);
  salaryForm.period_end = end.toISOString().slice(0, 10);
  salaryForm.base_pay_display = formatMoney(breakdown?.basePayCentavos ?? 0);
  salaryForm.commission_display = formatMoney(breakdown?.commissionCentavos ?? 0);
  salaryForm.gross_display = formatMoney(breakdown?.grossCentavos ?? 0);
  salaryForm.notes = '';
  salaryModalOpen.value = true;
}

async function saveSalaryRecord() {
  if (!employee.value) {
    return;
  }

  salarySaving.value = true;
  const base = parseMoney(salaryForm.base_pay_display);
  const commission = parseMoney(salaryForm.commission_display);
  const gross = parseMoney(salaryForm.gross_display);

  await createSalaryRecord({
    tenant_id: tenantId.value,
    branch_id: branchId.value,
    employee_id: employee.value.id,
    period_start: salaryForm.period_start,
    period_end: salaryForm.period_end,
    base_pay_centavos: base,
    commission_centavos: commission,
    gross_centavos: gross,
    net_centavos: gross,
    notes: salaryForm.notes || undefined,
  });
  salaryModalOpen.value = false;
  await load();
  salarySaving.value = false;
}

async function submitRecord(record: SalaryRecord) {
  if (!auth.authUser) {
    return;
  }

  await submitSalaryRecord(record.id, auth.authUser.id);
  await load();
}
</script>

<template>
  <div class="h-full overflow-y-auto p-6">
    <div v-if="loading" class="flex justify-center py-12">
      <BaseSpinner size="lg" />
    </div>

    <div v-else-if="employee" class="space-y-6">
      <!-- Header -->
      <div class="flex items-start justify-between">
        <div>
          <h1 class="text-2xl font-bold text-casual-navy">{{ employee.full_name }}</h1>
          <p class="text-sm text-oslo">Employee profile and payroll</p>
          <BaseBadge :variant="employee.role === 'admin' ? 'info' : 'default'" class="mt-1">{{ employee.role }}</BaseBadge>
        </div>
        <div class="flex gap-2">
          <BaseButton :variant="todayAttendance?.status === 'present' ? 'secondary' : 'primary'" size="sm" @click="toggleTodayAttendance">
            {{ todayAttendance?.status === 'present' ? 'Mark absent' : 'Mark present' }}
          </BaseButton>
        </div>
      </div>

      <!-- Income cards -->
      <div class="grid gap-3 grid-cols-3">
        <!-- Today -->
        <BaseCard padding="sm">
          <p class="text-xs font-medium text-oslo uppercase tracking-wide">Today</p>
          <p class="mt-1 text-xl font-semibold num text-casual-navy">{{ formatMoney(todayIncome?.grossCentavos ?? 0) }}</p>
          <p class="mt-0.5 text-xs text-independence">
            Base: {{ formatMoney(todayIncome?.basePayCentavos ?? 0) }} · Commission: {{ formatMoney(todayIncome?.commissionCentavos ?? 0) }}
          </p>
          <BaseButton variant="ghost" size="sm" class="mt-2 w-full" @click="openCreateSalary('today')">Create salary record</BaseButton>
        </BaseCard>

        <!-- This week -->
        <BaseCard padding="sm">
          <p class="text-xs font-medium text-oslo uppercase tracking-wide">This week</p>
          <p class="mt-1 text-xl font-semibold num text-casual-navy">{{ formatMoney(weekIncome?.grossCentavos ?? 0) }}</p>
          <p class="mt-0.5 text-xs text-independence">
            Base: {{ formatMoney(weekIncome?.basePayCentavos ?? 0) }} · Commission: {{ formatMoney(weekIncome?.commissionCentavos ?? 0) }}
          </p>
          <BaseButton variant="ghost" size="sm" class="mt-2 w-full" @click="openCreateSalary('this_week')">Create salary record</BaseButton>
        </BaseCard>

        <!-- This month -->
        <BaseCard padding="sm">
          <p class="text-xs font-medium text-oslo uppercase tracking-wide">This month</p>
          <p class="mt-1 text-xl font-semibold num text-casual-navy">{{ formatMoney(monthIncome?.grossCentavos ?? 0) }}</p>
          <p class="mt-0.5 text-xs text-independence">
            Base: {{ formatMoney(monthIncome?.basePayCentavos ?? 0) }} · Commission: {{ formatMoney(monthIncome?.commissionCentavos ?? 0) }}
          </p>
          <BaseButton variant="ghost" size="sm" class="mt-2 w-full" @click="openCreateSalary('this_month')">Create salary record</BaseButton>
        </BaseCard>
      </div>

      <!-- Salary records -->
      <div>
        <h2 class="mb-3 text-sm font-medium text-independence uppercase tracking-wide">Salary records</h2>
        <BaseEmptyState v-if="salaryRecords.length === 0" title="No salary records yet" />
        <BaseCard v-else padding="none">
          <BaseTable>
            <template #head>
              <BaseTr>
                <BaseTh>Period</BaseTh>
                <BaseTh>Base pay</BaseTh>
                <BaseTh>Commission</BaseTh>
                <BaseTh>Gross</BaseTh>
                <BaseTh>Status</BaseTh>
                <BaseTh></BaseTh>
              </BaseTr>
            </template>
            <template #body>
              <BaseTr v-for="r in salaryRecords" :key="r.id">
                <BaseTd>{{ r.period_start }} – {{ r.period_end }}</BaseTd>
                <BaseTd class="num">{{ formatMoney(r.base_pay_centavos) }}</BaseTd>
                <BaseTd class="num">{{ formatMoney(r.commission_centavos) }}</BaseTd>
                <BaseTd class="num">{{ formatMoney(r.gross_centavos) }}</BaseTd>
                <BaseTd>
                  <BaseBadge :variant="r.paid_at ? 'success' : 'warning'">
                    {{ r.paid_at ? 'Paid' : 'Draft' }}
                  </BaseBadge>
                </BaseTd>
                <BaseTd class="text-right">
                  <BaseButton v-if="!r.paid_at" variant="ghost" size="sm" @click="submitRecord(r)"> Mark paid </BaseButton>
                </BaseTd>
              </BaseTr>
            </template>
          </BaseTable>
        </BaseCard>
      </div>
    </div>

    <!-- Salary modal -->
    <BaseModal :open="salaryModalOpen" title="Create salary record" @close="salaryModalOpen = false">
      <form id="salary-record-form" class="space-y-4" @submit.prevent="saveSalaryRecord">
        <div class="grid grid-cols-2 gap-3">
          <BaseInput v-model="salaryForm.period_start" label="Period start" type="date" :required="true" />
          <BaseInput v-model="salaryForm.period_end" label="Period end" type="date" :required="true" />
        </div>
        <BaseInput v-model="salaryForm.base_pay_display" label="Base pay" placeholder="₱0.00" />
        <BaseInput v-model="salaryForm.commission_display" label="Commission" placeholder="₱0.00" />
        <BaseInput v-model="salaryForm.gross_display" label="Gross (editable)" placeholder="₱0.00" />
        <BaseTextarea v-model="salaryForm.notes" label="Notes" :rows="2" />
      </form>
      <template #footer>
        <BaseButton variant="ghost" @click="salaryModalOpen = false">Cancel</BaseButton>
        <BaseButton type="submit" form="salary-record-form" :loading="salarySaving">Save record</BaseButton>
      </template>
    </BaseModal>
  </div>
</template>
