<script setup lang="ts">
const router = useRouter();

router.replace('/dashboard');
</script>

<template>
  <div />
</template>
