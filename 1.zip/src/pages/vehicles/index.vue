<script setup lang="ts">
import type { Vehicle, MaintenanceTask } from '@/types/database';

const auth = useAuthStore();

// Data
const vehicles = ref<Vehicle[]>([]);
const allTasks = ref<MaintenanceTask[]>([]);
const loading = ref(false);

// Modal state
const modalOpen = ref(false);
const editingVehicle = ref<Vehicle | null>(null);
const saving = ref(false);
const deleteTarget = ref<Vehicle | null>(null);

// Form
const form = reactive({
  type: '',
  brand_model: '',
  plate_number: '',
  year: '' as string | number,
  notes: '',
});

const vehicleTypeOptions = [
  { label: 'Motorcycle', value: 'motorcycle' },
  { label: 'Tricycle', value: 'tricycle' },
  { label: 'Truck', value: 'truck' },
  { label: 'Van', value: 'van' },
  { label: 'Other', value: 'other' },
];

const currentYear = new Date().getFullYear();

// PM badge computation
const today = new Date().toISOString().slice(0, 10);
const weekLater = new Date(Date.now() + 7 * 86400000).toISOString().slice(0, 10);

function getVehiclePMBadges(vehicle: Vehicle) {
  const tasks = allTasks.value.filter((t) => t.vehicle_id === vehicle.id && t.active && !t.deleted_at);
  const overdueCount = tasks.filter((t) => t.next_due_at && t.next_due_at < today).length;
  const dueSoonCount = tasks.filter((t) => t.next_due_at && t.next_due_at >= today && t.next_due_at <= weekLater).length;

  return { overdueCount, dueSoonCount };
}

function labelForType(type: string): string {
  return vehicleTypeOptions.find((o) => o.value === type)?.label ?? type;
}

async function load() {
  loading.value = true;
  const rows = await listVehicles();

  vehicles.value = rows;
  if (rows.length > 0) {
    allTasks.value = await listVehicleMaintenanceTasks(rows.map((v) => v.id));
  } else {
    allTasks.value = [];
  }

  loading.value = false;
}

onMounted(load);

function openAdd() {
  editingVehicle.value = null;
  form.type = '';
  form.brand_model = '';
  form.plate_number = '';
  form.year = '';
  form.notes = '';
  modalOpen.value = true;
}

function openEdit(v: Vehicle) {
  editingVehicle.value = v;
  form.type = v.type;
  form.brand_model = v.brand_model ?? '';
  form.plate_number = v.plate_number ?? '';
  form.year = v.year ?? '';
  form.notes = v.notes ?? '';
  modalOpen.value = true;
}

async function save() {
  saving.value = true;
  const payload = {
    type: form.type,
    brand_model: form.brand_model,
    plate_number: form.plate_number,
    year: form.year !== '' ? Number(form.year) : null,
    notes: form.notes || null,
  };

  if (editingVehicle.value) {
    await updateVehicle(editingVehicle.value.id, payload);
  } else {
    await createVehicle(payload);
  }

  modalOpen.value = false;
  await load();
  saving.value = false;
}

async function confirmDelete() {
  if (!deleteTarget.value) {
    return;
  }

  await deleteVehicle(deleteTarget.value.id);
  deleteTarget.value = null;
  await load();
}
</script>

<template>
  <div class="h-full overflow-y-auto p-6">
    <div class="space-y-4">
      <!-- Header -->
      <div class="flex items-center justify-between">
        <div>
          <h1 class="text-2xl font-bold text-casual-navy">Vehicles</h1>
          <p class="text-sm text-oslo">Manage fleet vehicles and assignments</p>
        </div>
        <BaseButton size="sm" @click="openAdd">Add Vehicle</BaseButton>
      </div>

      <!-- Loading -->
      <BaseSpinner v-if="loading" class="mx-auto mt-8" />

      <!-- Empty state -->
      <BaseEmptyState v-else-if="vehicles.length === 0" title="No vehicles registered">
        <template #actions>
          <BaseButton size="sm" @click="openAdd">Add first vehicle</BaseButton>
        </template>
      </BaseEmptyState>

      <!-- Table -->
      <BaseTable v-else>
        <template #head>
          <tr>
            <BaseTh>Brand / Model</BaseTh>
            <BaseTh>Type</BaseTh>
            <BaseTh>Plate Number</BaseTh>
            <BaseTh>Year</BaseTh>
            <BaseTh>PM Status</BaseTh>
            <BaseTh class="text-right">Actions</BaseTh>
          </tr>
        </template>
        <template #body>
          <BaseTr v-for="v in vehicles" :key="v.id">
            <BaseTd class="font-medium text-casual-navy">{{ v.brand_model }}</BaseTd>
            <BaseTd class="text-independence">{{ labelForType(v.type) }}</BaseTd>
            <BaseTd class="num text-casual-navy">{{ v.plate_number }}</BaseTd>
            <BaseTd class="num text-independence">{{ v.year ?? '—' }}</BaseTd>
            <BaseTd>
              <div class="flex flex-wrap gap-1">
                <template v-if="getVehiclePMBadges(v).overdueCount > 0 || getVehiclePMBadges(v).dueSoonCount > 0">
                  <BaseBadge v-if="getVehiclePMBadges(v).overdueCount > 0" variant="danger" size="sm">
                    {{ getVehiclePMBadges(v).overdueCount }} overdue
                  </BaseBadge>
                  <BaseBadge v-if="getVehiclePMBadges(v).dueSoonCount > 0" variant="warning" size="sm">
                    {{ getVehiclePMBadges(v).dueSoonCount }} due this week
                  </BaseBadge>
                </template>
                <BaseBadge v-else variant="success" size="sm">OK</BaseBadge>
              </div>
            </BaseTd>
            <BaseTd class="text-right">
              <div class="flex justify-end gap-2">
                <BaseButton variant="ghost" size="sm" @click="openEdit(v)">Edit</BaseButton>
                <BaseButton variant="ghost" size="sm" class="text-blaze-red" @click="deleteTarget = v"> Delete </BaseButton>
              </div>
            </BaseTd>
          </BaseTr>
        </template>
      </BaseTable>
    </div>

    <!-- Add / Edit modal -->
    <BaseModal :open="modalOpen" :title="editingVehicle ? 'Edit Vehicle' : 'Add Vehicle'" @close="modalOpen = false">
      <form id="vehicle-form" class="space-y-4" @submit.prevent="save">
        <BaseSelect v-model="form.type" label="Type" :options="vehicleTypeOptions" placeholder="Select type..." :required="true" />
        <BaseInput v-model="form.brand_model" label="Brand / Model" placeholder="e.g. Honda Wave 125" :required="true" />
        <BaseInput v-model="form.plate_number" label="Plate Number" placeholder="e.g. ABC 1234" :required="true" />
        <BaseInput v-model="form.year" label="Year (optional)" type="number" :min="1990" :max="currentYear" placeholder="e.g. 2022" />
        <BaseTextarea v-model="form.notes" label="Notes (optional)" :rows="3" />
      </form>
      <template #footer>
        <BaseButton variant="ghost" @click="modalOpen = false">Cancel</BaseButton>
        <BaseButton type="submit" form="vehicle-form" :loading="saving">
          {{ editingVehicle ? 'Save changes' : 'Add Vehicle' }}
        </BaseButton>
      </template>
    </BaseModal>

    <!-- Delete confirm -->
    <BaseConfirm
      :open="deleteTarget !== null"
      title="Delete vehicle?"
      :message="`Delete '${deleteTarget?.brand_model}'? This cannot be undone.`"
      @confirm="confirmDelete"
      @cancel="deleteTarget = null"
    />
  </div>
</template>
