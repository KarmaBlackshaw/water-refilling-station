<script setup lang="ts">
import type { Area, User } from '@/types/database';

const auth = useAuthStore();
const tenantId = computed(() => auth.tenantId ?? '');
const branchId = computed(() => auth.branchId ?? '');

// Areas list
const areas = ref<Array<Area & { primary_rider: { id: string; full_name: string } | null }>>([]);
const areasLoading = ref(false);

// Riders list for select options
const riders = ref<Array<Pick<User, 'id' | 'full_name'>>>([]);

// Area modal
const areaModalOpen = ref(false);
const editingArea = ref<Area | null>(null);
const areaForm = reactive({ name: '', notes: '', primary_rider_id: '' });
const areaSaving = ref(false);
const deleteAreaConfirm = ref<Area | null>(null);

// Coverage modal
const coverageModalOpen = ref(false);
const coverageArea = ref<Area | null>(null);
const coverageForm = reactive({ covering_rider_id: '', starts_on: '', ends_on: '' });
const coverageSaving = ref(false);

async function load() {
  areasLoading.value = true;
  const [areasRes, ridersRes] = await Promise.all([listAreas(tenantId.value, branchId.value), listRiders(tenantId.value, branchId.value)]);

  areas.value = (areasRes.data ?? []) as typeof areas.value;
  riders.value = (ridersRes.data ?? []) as Array<Pick<User, 'id' | 'full_name'>>;
  areasLoading.value = false;
}

onMounted(load);

const riderOptions = computed(() => riders.value.map((r) => ({ label: r.full_name, value: r.id })));

function openAddArea() {
  editingArea.value = null;
  areaForm.name = '';
  areaForm.notes = '';
  areaForm.primary_rider_id = '';
  areaModalOpen.value = true;
}

function openEditArea(a: Area) {
  editingArea.value = a;
  areaForm.name = a.name;
  areaForm.notes = a.notes ?? '';
  areaForm.primary_rider_id = a.primary_rider_id ?? '';
  areaModalOpen.value = true;
}

async function saveArea() {
  areaSaving.value = true;
  const payload = {
    name: areaForm.name,
    notes: areaForm.notes || null,
    primary_rider_id: areaForm.primary_rider_id || null,
  };

  if (editingArea.value) {
    await updateArea(editingArea.value.id, payload);
  } else {
    await createArea({ tenant_id: tenantId.value, branch_id: branchId.value, ...payload });
  }

  areaModalOpen.value = false;
  await load();
  areaSaving.value = false;
}

async function confirmDeleteArea() {
  if (!deleteAreaConfirm.value || !auth.authUser) {
    return;
  }

  await softDeleteArea(deleteAreaConfirm.value.id, auth.authUser.id);
  deleteAreaConfirm.value = null;
  await load();
}

function openCoverage(a: Area) {
  coverageArea.value = a;
  coverageForm.covering_rider_id = '';
  coverageForm.starts_on = new Date().toISOString().slice(0, 10);
  coverageForm.ends_on = '';
  coverageModalOpen.value = true;
}

async function saveCoverage() {
  if (!coverageArea.value) {
    return;
  }

  coverageSaving.value = true;
  await createCoverageRecord({
    tenant_id: tenantId.value,
    branch_id: branchId.value,
    area_id: coverageArea.value.id,
    covering_rider_id: coverageForm.covering_rider_id,
    starts_on: coverageForm.starts_on,
    ends_on: coverageForm.ends_on || null,
  });
  coverageModalOpen.value = false;
  await load();
  coverageSaving.value = false;
}
</script>

<template>
  <div class="h-full overflow-y-auto p-6">
    <div class="space-y-4">
      <div class="flex items-center justify-between">
        <div>
          <h1 class="text-2xl font-bold text-casual-navy">Areas</h1>
          <p class="text-sm text-oslo">Manage delivery areas and coverage zones</p>
        </div>
        <BaseButton size="sm" @click="openAddArea">Add area</BaseButton>
      </div>

      <BaseSpinner v-if="areasLoading" class="mx-auto mt-8" />
      <BaseEmptyState v-else-if="areas.length === 0" title="No areas yet">
        <template #actions>
          <BaseButton size="sm" @click="openAddArea">Add first area</BaseButton>
        </template>
      </BaseEmptyState>

      <div v-else class="space-y-3">
        <BaseCard v-for="a in areas" :key="a.id" padding="sm">
          <div class="flex items-start justify-between gap-4">
            <div>
              <p class="font-medium text-casual-navy">{{ a.name }}</p>
              <p v-if="a.primary_rider" class="mt-0.5 text-sm text-independence">Primary rider: {{ a.primary_rider.full_name }}</p>
              <p v-else class="mt-0.5 text-sm text-independence">No primary rider assigned</p>
              <p v-if="a.notes" class="mt-1 text-xs text-independence">{{ a.notes }}</p>
            </div>
            <div class="flex shrink-0 gap-2">
              <BaseButton variant="ghost" size="sm" @click="openCoverage(a)">Add coverage</BaseButton>
              <BaseButton variant="ghost" size="sm" @click="openEditArea(a)">Edit</BaseButton>
              <BaseButton variant="ghost" size="sm" class="text-blaze-red" @click="deleteAreaConfirm = a">Delete</BaseButton>
            </div>
          </div>
        </BaseCard>
      </div>
    </div>

    <!-- Area modal -->
    <BaseModal :open="areaModalOpen" :title="editingArea ? 'Edit area' : 'Add area'" @close="areaModalOpen = false">
      <form id="area-form" class="space-y-4" @submit.prevent="saveArea">
        <BaseInput v-model="areaForm.name" label="Area name" :required="true" />
        <BaseSelect v-model="areaForm.primary_rider_id" label="Primary rider" :options="riderOptions" placeholder="Select rider..." />
        <BaseTextarea v-model="areaForm.notes" label="Notes" :rows="2" />
      </form>
      <template #footer>
        <BaseButton variant="ghost" @click="areaModalOpen = false">Cancel</BaseButton>
        <BaseButton type="submit" form="area-form" :loading="areaSaving">Save</BaseButton>
      </template>
    </BaseModal>

    <!-- Coverage modal -->
    <BaseModal :open="coverageModalOpen" :title="`Add coverage — ${coverageArea?.name ?? ''}`" @close="coverageModalOpen = false">
      <form id="coverage-form" class="space-y-4" @submit.prevent="saveCoverage">
        <BaseSelect v-model="coverageForm.covering_rider_id" label="Covering rider" :options="riderOptions" :required="true" />
        <BaseInput v-model="coverageForm.starts_on" label="Starts on" type="date" :required="true" />
        <BaseInput v-model="coverageForm.ends_on" label="Ends on (leave blank for open-ended)" type="date" />
      </form>
      <template #footer>
        <BaseButton variant="ghost" @click="coverageModalOpen = false">Cancel</BaseButton>
        <BaseButton type="submit" form="coverage-form" :loading="coverageSaving">Add coverage</BaseButton>
      </template>
    </BaseModal>

    <!-- Delete confirm -->
    <BaseConfirm
      :open="deleteAreaConfirm !== null"
      title="Delete area?"
      :message="`Delete '${deleteAreaConfirm?.name}'? Coverage records will also be removed.`"
      @confirm="confirmDeleteArea"
      @cancel="deleteAreaConfirm = null"
    />
  </div>
</template>
