import { createRouter, createWebHistory } from 'vue-router';
import { routes, handleHotUpdate } from 'vue-router/auto-routes';
import { useAuthStore } from '@/stores/auth';

export const router = createRouter({
  history: createWebHistory(),
  routes,
});

// This will update routes at runtime without reloading the page
if (import.meta.hot) {
  handleHotUpdate(router);
}

router.beforeEach(async (to) => {
  const auth = useAuthStore();

  if (auth.loading) {
    await auth.initialize();
  }

  const publicRoutes = ['/login'];

  if (!publicRoutes.includes(to.path) && !auth.isAuthenticated) {
    return '/login';
  }

  if (to.path === '/login' && auth.isAuthenticated) {
    return '/dashboard';
  }
});
