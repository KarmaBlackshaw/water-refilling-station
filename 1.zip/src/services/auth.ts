import { supabase } from '@/helpers/supabase';
import type { User } from '@/types/database';

export async function signIn(email: string, password: string) {
  return supabase.auth.signInWithPassword({ email, password });
}

export async function signOut() {
  return supabase.auth.signOut();
}

export async function fetchProfile(userId: string): Promise<{ data: User | null; error: unknown }> {
  const { data, error } = await supabase.from('users').select('*').eq('id', userId).single();

  return { data: data as User | null, error };
}
