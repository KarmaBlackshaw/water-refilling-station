import { supabase } from '@/helpers/supabase';
import type { Sale } from '@/types/database';

export interface DeliverySaleRow {
  id: string;
  status: string;
  customer_id: string | null;
  address_id: string | null;
  rider_id: string | null;
  sale_date: string;
  notes: string | null;
  customer: { name: string; phone: string | null } | null;
  address: { address_line: string; label: string } | null;
  rider: { full_name: string } | null;
  lines: Array<{
    id: string;
    product_id: string;
    container_type_id: string;
    quantity: number;
    unit_price_centavos: number;
    is_new_container: boolean;
    product: { name: string } | null;
    container_type: { name: string } | null;
  }>;
}

function todayISO(): string {
  return new Date().toISOString().slice(0, 10);
}

export async function listDeliverySales(date?: string): Promise<DeliverySaleRow[]> {
  const targetDate = date ?? todayISO();

  const { data, error } = await supabase
    .from('sales')
    .select(
      `
      *,
      customer:customers(name, phone),
      address:customer_addresses(address_line, label),
      rider:users!rider_id(full_name),
      lines:sale_lines(*, product:products(name), container_type:container_types(name))
    `,
    )
    .in('source', ['delivery', 'booking_fulfilled'])
    .neq('status', 'void')
    .is('deleted_at', null)
    .eq('sale_date', targetDate)
    .order('created_at', { ascending: true });

  if (error) {
    throw error;
  }

  return (data ?? []) as unknown as DeliverySaleRow[];
}

export async function createDeliverySale(data: {
  customer_id: string;
  address_id?: string | null;
  rider_id?: string | null;
  sale_date: string;
  tenant_id: string;
  branch_id: string;
  lines: Array<{
    product_id: string;
    container_type_id: string;
    quantity: number;
    unit_price_centavos: number;
    is_new_container: boolean;
  }>;
  payments: Array<{
    method: string;
    amount_centavos: number;
    gcash_ref?: string | null;
  }>;
  notes?: string | null;
}): Promise<Sale> {
  const { data: sale, error: saleError } = await supabase
    .from('sales')
    .insert({
      tenant_id: data.tenant_id,
      branch_id: data.branch_id,
      source: 'delivery',
      status: 'pending_delivery',
      customer_id: data.customer_id,
      address_id: data.address_id ?? null,
      rider_id: data.rider_id ?? null,
      sale_date: data.sale_date,
      notes: data.notes ?? null,
    })
    .select()
    .single();

  if (saleError) {
    throw saleError;
  }

  if (data.lines.length > 0) {
    const { error: linesError } = await supabase.from('sale_lines').insert(
      data.lines.map((l) => ({
        tenant_id: data.tenant_id,
        branch_id: data.branch_id,
        sale_id: sale.id,
        product_id: l.product_id,
        container_type_id: l.container_type_id,
        quantity: l.quantity,
        unit_price_centavos: l.unit_price_centavos,
        is_new_container: l.is_new_container,
      })),
    );

    if (linesError) {
      throw linesError;
    }
  }

  if (data.payments.length > 0) {
    const { error: paymentsError } = await supabase.from('sale_payments').insert(
      data.payments.map((p) => ({
        tenant_id: data.tenant_id,
        branch_id: data.branch_id,
        sale_id: sale.id,
        method: p.method,
        amount_centavos: p.amount_centavos,
        gcash_ref: p.gcash_ref ?? null,
      })),
    );

    if (paymentsError) {
      throw paymentsError;
    }
  }

  return sale as Sale;
}

export async function reconcileDelivery(data: {
  saleId: string;
  customerId: string | null;
  tenantId: string;
  branchId: string;
  containersReturned: Array<{
    container_type_id: string;
    quantity: number;
  }>;
  notes?: string | null;
}): Promise<void> {
  const { error: updateError } = await supabase.from('sales').update({ status: 'completed' }).eq('id', data.saleId);

  if (updateError) {
    throw updateError;
  }

  const movements = data.containersReturned.filter((c) => c.quantity > 0);

  if (movements.length === 0) {
    return;
  }

  const { error: movError } = await supabase.from('container_movements').insert(
    movements.map((c) => ({
      tenant_id: data.tenantId,
      branch_id: data.branchId,
      customer_id: data.customerId,
      container_type_id: c.container_type_id,
      sale_id: data.saleId,
      movement_type: 'in',
      quantity: c.quantity,
      movement_date: todayISO(),
      notes: data.notes ?? null,
    })),
  );

  if (movError) {
    throw movError;
  }
}
