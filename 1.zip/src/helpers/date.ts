import dayjs from 'dayjs';

export { dayjs };

export function formatDate(date: string | Date | null | undefined, format = 'YYYY-MM-DD'): string {
  if (!date) {
    return '';
  }

  return dayjs(date).format(format);
}

export function formatDateTime(date: string | Date | null | undefined): string {
  if (!date) {
    return '';
  }

  return dayjs(date).format('YYYY-MM-DD HH:mm');
}

export function formatDateDisplay(date: string | Date | null | undefined): string {
  if (!date) {
    return '';
  }

  return dayjs(date).format('MMM D, YYYY');
}

export function formatDateLong(date: string | Date | null | undefined): string {
  if (!date) {
    return '-';
  }

  return dayjs(date).format('MMMM D, YYYY');
}

export function addDays(date: string | Date, days: number): string {
  return dayjs(date).add(days, 'day').format('YYYY-MM-DD');
}

export function today(): string {
  return dayjs().format('YYYY-MM-DD');
}

export function isValidDate(date: string | Date | null | undefined): boolean {
  if (!date) {
    return false;
  }

  return dayjs(date).isValid();
}

export function diffInDays(date1: string | Date, date2: string | Date): number {
  return dayjs(date1).diff(dayjs(date2), 'day');
}

export function getNextBillingDate(checkInDate: string | Date): string {
  const checkIn = dayjs(checkInDate);
  const todayDate = dayjs();

  // Get the day of month from check-in date (e.g., if check-in is 15th, billing is every 15th)
  let billingDay = checkIn.date();

  // Handle edge cases for days that don't exist in all months (29, 30, 31)
  // If billing day is 31 and month only has 30 days, use last day of month
  const daysInCurrentMonth = todayDate.daysInMonth();

  if (billingDay > daysInCurrentMonth) {
    billingDay = daysInCurrentMonth;
  }

  // Start with this month's billing date
  let nextBilling = todayDate.date(billingDay);

  // If we've passed this month's billing date, move to next month
  if (nextBilling.isBefore(todayDate) || nextBilling.isSame(todayDate, 'day')) {
    nextBilling = nextBilling.add(1, 'month');
    // Re-check days in the next month
    const daysInNextMonth = nextBilling.daysInMonth();
    const originalBillingDay = checkIn.date();

    if (originalBillingDay > daysInNextMonth) {
      nextBilling = nextBilling.date(daysInNextMonth);
    } else {
      nextBilling = nextBilling.date(originalBillingDay);
    }
  }

  return nextBilling.format('YYYY-MM-DD');
}

export function getDaysUntilBilling(checkInDate: string | Date): number {
  const nextBilling = getNextBillingDate(checkInDate);

  return dayjs(nextBilling).diff(dayjs(), 'day');
}

export function formatCurrency(amount: number): string {
  return `₱${amount.toLocaleString()}`;
}
