// Monday=0 through Saturday=5 are workdays; Sunday=6 is rest day
function isWorkday(date: Date): boolean {
  const dow = date.getDay(); // 0=Sun, 1=Mon, ..., 6=Sat

  return dow >= 1 && dow <= 6;
}

export function countWorkdays(start: Date, end: Date): number {
  let count = 0;
  const current = new Date(start);

  current.setHours(0, 0, 0, 0);
  const endDate = new Date(end);

  endDate.setHours(0, 0, 0, 0);
  while (current <= endDate) {
    if (isWorkday(current)) {
      count++;
    }

    current.setDate(current.getDate() + 1);
  }
  return count;
}

export function dailyRateCentavos(monthlyCentavos: number, year: number, month: number): number {
  const firstDay = new Date(year, month - 1, 1);
  const lastDay = new Date(year, month, 0);
  const workdays = countWorkdays(firstDay, lastDay);

  if (workdays === 0) {
    return 0;
  }

  return Math.floor(monthlyCentavos / workdays);
}

export function isWorkdayDate(date: Date): boolean {
  return isWorkday(date);
}

// Returns array of workday Date objects between start and end inclusive
export function getWorkdays(start: Date, end: Date): Date[] {
  const days: Date[] = [];
  const current = new Date(start);

  current.setHours(0, 0, 0, 0);
  const endDate = new Date(end);

  endDate.setHours(0, 0, 0, 0);
  while (current <= endDate) {
    if (isWorkday(current)) {
      days.push(new Date(current));
    }

    current.setDate(current.getDate() + 1);
  }
  return days;
}
