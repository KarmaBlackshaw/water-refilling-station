import { supabase } from '@/helpers/supabase';
import type { CustomerPriceOverride, ProductPricing } from '@/types/database';

export function usePriceResolver() {
  const overrides = ref<CustomerPriceOverride[]>([]);
  const pricing = ref<ProductPricing[]>([]);
  const loading = ref(false);

  async function loadPricing(customerId?: string | null) {
    loading.value = true;
    const today = new Date().toISOString().slice(0, 10);

    const [overridesRes, pricingRes] = await Promise.all([
      customerId
        ? supabase.from('customer_price_overrides').select('*').eq('customer_id', customerId).is('deleted_at', null)
        : Promise.resolve({ data: [] as CustomerPriceOverride[], error: null }),
      supabase.from('product_pricing').select('*').lte('effective_from', today).order('effective_from', { ascending: false }),
    ]);

    overrides.value = (overridesRes.data ?? []) as CustomerPriceOverride[];
    pricing.value = (pricingRes.data ?? []) as ProductPricing[];
    loading.value = false;
  }

  function resolvePrice(productId: string, containerTypeId: string, isNewContainer: boolean): number {
    const override = overrides.value.find((o) => o.product_id === productId && o.container_type_id === containerTypeId);

    if (override) {
      return isNewContainer ? override.new_container_price_centavos : override.refill_price_centavos;
    }

    const base = pricing.value.find((p) => p.product_id === productId && p.container_type_id === containerTypeId);

    if (base) {
      return isNewContainer ? base.new_container_price_centavos : base.refill_price_centavos;
    }

    return 0;
  }

  return { loadPricing, resolvePrice, loading };
}
