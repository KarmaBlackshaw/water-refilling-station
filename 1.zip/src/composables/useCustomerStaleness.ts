import { useTenantStore } from '@/stores/tenant';

export function useCustomerStaleness() {
  const tenant = useTenantStore();

  function getDaysSinceOrder(lastOrderDate: string | null): number | null {
    if (!lastOrderDate) {
      return null;
    }

    const last = new Date(lastOrderDate);
    const now = new Date();
    const diffMs = now.getTime() - last.getTime();

    return Math.floor(diffMs / (1000 * 60 * 60 * 24));
  }

  function isStale(lastOrderDate: string | null, type: 'delivery' | 'walkin'): boolean {
    const days = getDaysSinceOrder(lastOrderDate);

    if (days === null) {
      return false;
    }

    const threshold = type === 'delivery' ? tenant.stalenessDaysDelivery : tenant.stalenessDaysWalkin;

    return days >= threshold;
  }

  return { getDaysSinceOrder, isStale };
}
