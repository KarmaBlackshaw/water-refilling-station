import { dailyRateCentavos, getWorkdays } from '@/helpers/workday';
import type { Employee, EmployeeAttendance } from '@/types/database';

export interface IncomeBreakdown {
  basePayCentavos: number;
  commissionCentavos: number;
  grossCentavos: number;
  workdaysPresent: number;
  totalWorkdays: number;
}

// Compute income for a period given attendance records and daily commissions
export function computeIncome(
  employee: Employee,
  periodStart: Date,
  periodEnd: Date,
  attendanceRecords: EmployeeAttendance[],
  dailyCommissions: Record<string, number>, // date string → centavos
): IncomeBreakdown {
  const year = periodStart.getFullYear();
  const month = periodStart.getMonth() + 1;
  const dailyRate = dailyRateCentavos(employee.monthly_salary_centavos, year, month);

  const workdays = getWorkdays(periodStart, periodEnd);
  const attendanceMap = new Map(attendanceRecords.map((a) => [a.attendance_date, a.status]));

  let workdaysPresent = 0;
  let commissionCentavos = 0;

  for (const day of workdays) {
    const dateStr = day.toISOString().slice(0, 10);
    const status = attendanceMap.get(dateStr);

    if (status === 'present') {
      workdaysPresent++;
    }

    commissionCentavos += dailyCommissions[dateStr] ?? 0;
  }

  const basePayCentavos = dailyRate * workdaysPresent;
  const grossCentavos = basePayCentavos + commissionCentavos;

  return {
    basePayCentavos,
    commissionCentavos,
    grossCentavos,
    workdaysPresent,
    totalWorkdays: workdays.length,
  };
}

// Get start/end dates for named periods
export function getPeriodDates(period: 'today' | 'this_week' | 'this_month'): {
  start: Date;
  end: Date;
} {
  const now = new Date();

  now.setHours(0, 0, 0, 0);

  if (period === 'today') {
    return { start: now, end: now };
  }

  if (period === 'this_week') {
    const day = now.getDay(); // 0=Sun, 1=Mon...
    const mondayOffset = day === 0 ? -6 : 1 - day;
    const monday = new Date(now);

    monday.setDate(now.getDate() + mondayOffset);
    const saturday = new Date(monday);

    saturday.setDate(monday.getDate() + 5);
    return { start: monday, end: saturday > now ? now : saturday };
  }

  // this_month
  const firstDay = new Date(now.getFullYear(), now.getMonth(), 1);

  return { start: firstDay, end: now };
}
