<script setup lang="ts">
import MainLayout from '@/layouts/MainLayout.vue'
const route = useRoute()
const isPublic = computed(() => route.path === '/login')
</script>

<template>
  <RouterView v-if="isPublic" />
  <MainLayout v-else />
</template>
