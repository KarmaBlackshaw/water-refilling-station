<script setup lang="ts">
const router = useRouter();
</script>

<template>
  <div>
    <p class="mb-2 text-[10px] font-bold uppercase tracking-widest text-casual-navy">Quick Actions</p>
    <div class="flex flex-col gap-1.5">
      <BaseButton variant="primary" size="sm" class="w-full justify-start" @click="router.push('/sales')"> + New Sale </BaseButton>
      <BaseButton variant="ghost" size="sm" class="w-full justify-start" @click="router.push('/bookings')"> + Add Booking </BaseButton>
      <BaseButton variant="ghost" size="sm" class="w-full justify-start" @click="router.push('/expenses')"> + Log Expense </BaseButton>
      <BaseButton variant="ghost" size="sm" class="w-full justify-start" @click="router.push('/deliveries')"> → View Deliveries </BaseButton>
    </div>
  </div>
</template>
