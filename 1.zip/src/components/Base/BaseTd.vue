<script setup lang="ts">
// No props — renders a styled <td> wrapper
</script>

<template>
  <td class="px-4 py-3 text-sm text-casual-navy border-b border-sparkling-silver">
    <slot />
  </td>
</template>
