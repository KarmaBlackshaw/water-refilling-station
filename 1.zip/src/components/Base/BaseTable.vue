<script setup lang="ts">
// No props — slots only
</script>

<template>
  <div class="w-full overflow-x-auto">
    <table class="w-full text-sm text-left">
      <thead>
        <slot name="head" />
      </thead>
      <tbody>
        <slot name="body" />
      </tbody>
    </table>
  </div>
</template>
