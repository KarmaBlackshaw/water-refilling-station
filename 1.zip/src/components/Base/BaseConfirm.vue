<script setup lang="ts">
defineProps<{
  open: boolean;
  title?: string;
  message?: string;
  confirmLabel?: string;
  cancelLabel?: string;
  variant?: 'danger' | 'primary';
  loading?: boolean;
}>();

defineEmits<{
  confirm: [];
  cancel: [];
}>();
</script>

<template>
  <BaseModal :open="open" :title="title ?? 'Are you sure?'" size="sm" :closable="true" @close="$emit('cancel')">
    <p v-if="message" class="text-sm text-independence">{{ message }}</p>

    <template #footer>
      <BaseButton variant="ghost" size="sm" :disabled="loading" @click="$emit('cancel')">
        {{ cancelLabel ?? 'Cancel' }}
      </BaseButton>
      <BaseButton :variant="variant ?? 'danger'" size="sm" :loading="loading" @click="$emit('confirm')">
        {{ confirmLabel ?? 'Confirm' }}
      </BaseButton>
    </template>
  </BaseModal>
</template>
