<script setup lang="ts">
import { Bar } from 'vue-chartjs';
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, Tooltip } from 'chart.js';

ChartJS.register(CategoryScale, LinearScale, BarElement, Tooltip);

const props = defineProps<{
  labels: string[];
  data: number[];
  title?: string;
  height?: number;
}>();

const chartData = computed(() => ({
  labels: props.labels,
  datasets: [
    {
      data: props.data,
      backgroundColor: 'rgba(0, 201, 240, 0.25)',
      hoverBackgroundColor: '#00C9F0',
      borderRadius: 4,
      borderSkipped: false,
    },
  ],
}));

const chartOptions = {
  responsive: true,
  maintainAspectRatio: false,
  animation: false as const,
  plugins: {
    legend: { display: false },
    tooltip: { enabled: true },
  },
  scales: {
    x: {
      grid: { display: false },
      border: { display: false },
      ticks: { color: '#94A3B8', font: { size: 11 } },
    },
    y: { display: false },
  },
};
</script>

<template>
  <div>
    <p v-if="title" class="mb-2 text-sm font-semibold text-casual-navy">{{ title }}</p>
    <div :style="{ height: `${height ?? 160}px` }">
      <Bar :data="chartData" :options="chartOptions" />
    </div>
  </div>
</template>
