<script setup lang="ts">
defineProps<{
  variant?: 'primary' | 'secondary' | 'ghost' | 'danger';
  size?: 'sm' | 'md' | 'lg';
  loading?: boolean;
  disabled?: boolean;
  type?: 'button' | 'submit' | 'reset';
}>();

const variantClasses = {
  primary: 'bg-turquoise-stone text-casual-navy font-semibold hover:opacity-90',
  secondary: 'bg-full-white text-casual-navy border border-sparkling-silver hover:bg-bright-chrome',
  ghost: 'text-independence hover:bg-hover',
  danger: 'bg-blaze-red text-white hover:opacity-90',
};

const sizeClasses = {
  sm: 'h-7 px-3 text-xs',
  md: 'h-9 px-4 text-sm',
  lg: 'h-10 px-5 text-sm',
};
</script>

<template>
  <button
    :type="type ?? 'button'"
    :disabled="disabled || loading"
    :class="[
      'inline-flex items-center justify-center gap-2 rounded font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-turquoise-stone',
      variantClasses[variant ?? 'primary'],
      sizeClasses[size ?? 'md'],
      disabled || loading ? 'opacity-50 cursor-not-allowed' : '',
    ]"
  >
    <svg v-if="loading" class="animate-spin size-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" aria-hidden="true">
      <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4" />
      <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
    </svg>
    <slot />
  </button>
</template>
