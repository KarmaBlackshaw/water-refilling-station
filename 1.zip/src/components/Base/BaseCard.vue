<script setup lang="ts">
defineProps<{
  padding?: 'none' | 'sm' | 'md' | 'lg';
  variant?: 'default' | 'hero';
  title?: string;
}>();

const paddingClasses = {
  none: '',
  sm: 'p-3',
  md: 'p-4',
  lg: 'p-6',
};

const variantClasses = {
  default: 'rounded-2xl border border-sparkling-silver bg-full-white shadow-sm',
  hero: 'rounded-2xl bg-turquoise-stone border-0 shadow-md',
};
</script>

<template>
  <div :class="[variantClasses[variant ?? 'default'], paddingClasses[padding ?? 'md']]">
    <div v-if="title || $slots.action" class="mb-3 flex items-center justify-between">
      <p v-if="title" class="text-sm font-semibold text-casual-navy">{{ title }}</p>
      <slot name="action" />
    </div>
    <slot />
  </div>
</template>
