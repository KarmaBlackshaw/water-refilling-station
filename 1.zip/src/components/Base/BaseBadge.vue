<script setup lang="ts">
defineProps<{
  variant?: 'default' | 'success' | 'warning' | 'danger' | 'info';
  size?: 'sm' | 'md';
}>();

const variantClasses = {
  default: 'bg-bright-chrome text-independence',
  success: 'bg-emerald-subtle text-dark-green-turquoise',
  warning: 'bg-amber-subtle text-strong-amber',
  danger: 'bg-red-subtle text-blaze-red',
  info: 'bg-turquoise-stone/10 text-bondi-blue',
};

const sizeClasses = {
  sm: 'px-2 py-0.5 text-xs rounded-sm',
  md: 'px-2.5 py-0.5 text-xs rounded',
};
</script>

<template>
  <span :class="['inline-flex items-center font-medium', variantClasses[variant ?? 'default'], sizeClasses[size ?? 'md']]">
    <slot />
  </span>
</template>
