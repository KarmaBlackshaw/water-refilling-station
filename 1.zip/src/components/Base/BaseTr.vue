<script setup lang="ts">
// No props — renders a styled <tr> wrapper
</script>

<template>
  <tr class="hover:bg-bright-chrome transition-colors">
    <slot />
  </tr>
</template>
