<script setup lang="ts">
// No props — renders a styled <th> wrapper
</script>

<template>
  <th class="px-4 py-3 text-xs font-semibold text-oslo uppercase tracking-wide bg-bright-chrome border-b border-sparkling-silver">
    <slot />
  </th>
</template>
