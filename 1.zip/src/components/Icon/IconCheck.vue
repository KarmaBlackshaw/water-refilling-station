<script setup lang="ts">
defineProps<{ size?: number }>();
</script>

<template>
  <svg :width="size || 20" :height="size || 20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
  </svg>
</template>
