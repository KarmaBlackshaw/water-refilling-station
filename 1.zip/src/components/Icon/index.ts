/** This file is auto generated */

export { default as IconAreas } from "./IconAreas.vue";
export { default as IconArrowUpRight } from "./IconArrowUpRight.vue";
export { default as IconBell } from "./IconBell.vue";
export { default as IconBookings } from "./IconBookings.vue";
export { default as IconBuilding } from "./IconBuilding.vue";
export { default as IconCheck } from "./IconCheck.vue";
export { default as IconCustomers } from "./IconCustomers.vue";
export { default as IconDashboard } from "./IconDashboard.vue";
export { default as IconDeliveries } from "./IconDeliveries.vue";
export { default as IconEmployees } from "./IconEmployees.vue";
export { default as IconExpenses } from "./IconExpenses.vue";
export { default as IconMail } from "./IconMail.vue";
export { default as IconMaintenance } from "./IconMaintenance.vue";
export { default as IconMenu } from "./IconMenu.vue";
export { default as IconMoney } from "./IconMoney.vue";
export { default as IconPlus } from "./IconPlus.vue";
export { default as IconProducts } from "./IconProducts.vue";
export { default as IconSales } from "./IconSales.vue";
export { default as IconSearch } from "./IconSearch.vue";
export { default as IconSettings } from "./IconSettings.vue";
export { default as IconVehicles } from "./IconVehicles.vue";
export { default as IconX } from "./IconX.vue";
