<script setup lang="ts">
import IconDashboard from '@/components/Icon/IconDashboard.vue';
import IconCustomers from '@/components/Icon/IconCustomers.vue';
import IconSales from '@/components/Icon/IconSales.vue';
import IconDeliveries from '@/components/Icon/IconDeliveries.vue';
import IconBookings from '@/components/Icon/IconBookings.vue';
import IconProducts from '@/components/Icon/IconProducts.vue';
import IconAreas from '@/components/Icon/IconAreas.vue';
import IconEmployees from '@/components/Icon/IconEmployees.vue';
import IconMaintenance from '@/components/Icon/IconMaintenance.vue';
import IconVehicles from '@/components/Icon/IconVehicles.vue';
import IconExpenses from '@/components/Icon/IconExpenses.vue';
import IconSettings from '@/components/Icon/IconSettings.vue';

const route = useRoute();

const MAIN_NAV = [
  { label: 'Dashboard', to: '/dashboard', icon: IconDashboard },
  { label: 'Customers', to: '/customers', icon: IconCustomers },
  { label: 'Sales', to: '/sales', icon: IconSales },
  { label: 'Deliveries', to: '/deliveries', icon: IconDeliveries },
  { label: 'Bookings', to: '/bookings', icon: IconBookings },
  { label: 'Products', to: '/products', icon: IconProducts },
  { label: 'Areas', to: '/areas', icon: IconAreas },
  { label: 'Employees', to: '/employees', icon: IconEmployees },
  { label: 'Maintenance', to: '/maintenance', icon: IconMaintenance },
  { label: 'Vehicles', to: '/vehicles', icon: IconVehicles },
  { label: 'Expenses', to: '/expenses', icon: IconExpenses },
];

const GENERAL_NAV = [{ label: 'Settings', to: '/settings', icon: IconSettings }];

function isActive(to: string) {
  return route.path.startsWith(to);
}
</script>

<template>
  <div class="flex h-full flex-col border-r border-sparkling-silver bg-full-white">
    <!-- Header -->
    <div class="flex items-center justify-between border-b border-sparkling-silver px-4 py-4">
      <div class="flex items-center gap-2">
        <div class="flex h-8 w-8 items-center justify-center rounded-lg bg-linear-to-br from-turquoise-stone to-cerulean">
          <span class="text-[10px] font-black text-white tracking-tight">WRS</span>
        </div>
        <div class="flex flex-col leading-none">
          <span class="text-sm font-bold text-casual-navy tracking-tight">WRS</span>
          <span class="text-[9px] uppercase tracking-widest text-oslo mt-0.5">Admin Portal</span>
        </div>
      </div>
    </div>

    <!-- Nav -->
    <nav class="flex-1 overflow-y-auto px-3 py-3 space-y-4">
      <div>
        <p class="mb-1 px-3 text-[10px] font-semibold uppercase tracking-widest text-oslo">Menu</p>
        <div class="space-y-0.5">
          <RouterLink
            v-for="item in MAIN_NAV"
            :key="item.to"
            :to="item.to"
            class="flex items-center gap-3 rounded-xl px-3 py-2 text-sm transition-colors"
            :class="
              isActive(item.to) ? 'bg-turquoise-stone/10 text-turquoise-stone font-medium' : 'text-independence hover:bg-bright-chrome hover:text-casual-navy'
            "
          >
            <component :is="item.icon" :size="16" class="shrink-0" />
            <span>{{ item.label }}</span>
          </RouterLink>
        </div>
      </div>

      <div>
        <p class="mb-1 px-3 text-[10px] font-semibold uppercase tracking-widest text-oslo">General</p>
        <div class="space-y-0.5">
          <RouterLink
            v-for="item in GENERAL_NAV"
            :key="item.to"
            :to="item.to"
            class="flex items-center gap-3 rounded-xl px-3 py-2 text-sm transition-colors"
            :class="
              isActive(item.to) ? 'bg-turquoise-stone/10 text-turquoise-stone font-medium' : 'text-independence hover:bg-bright-chrome hover:text-casual-navy'
            "
          >
            <component :is="item.icon" :size="16" class="shrink-0" />
            <span>{{ item.label }}</span>
          </RouterLink>
        </div>
      </div>
    </nav>

    <!-- Footer -->
    <div class="border-t border-sparkling-silver px-3 py-3">
      <span class="text-oslo text-xs">v0.1.0</span>
    </div>
  </div>
</template>
